﻿using System;

class Program
{
    static void Main(string[] args)
    {
       
        Console.WriteLine("Welcome to the Recipe App!");
        Console.WriteLine("============================");

        bool exit = false;
        Recipe recipe = new Recipe();

        while (!exit)
        {
            // Menu options
            Console.WriteLine("\nMenu:");
            Console.WriteLine("1. Enter recipe details");
            Console.WriteLine("2. Display recipe");
            Console.WriteLine("3. Scale recipe");
            Console.WriteLine("4. Reset quantities");
            Console.WriteLine("5. Clear all data");
            Console.WriteLine("6. Exit");
            Console.Write("Enter your choice: ");

            int choice;
            // Input validation for menu choice
            if (!int.TryParse(Console.ReadLine(), out choice))
            {
                Console.WriteLine("Invalid choice. Please try again.");
                continue;
            }

            switch (choice)
            {
                case 1:
                    recipe.EnterDetails();
                    break;
                case 2:
                    recipe.Display();
                    break;
                case 3:
                    recipe.Scale();
                    break;
                case 4:
                    recipe.ResetQuantities();
                    break;
                case 5:
                    recipe.ClearData();
                    break;
                case 6:
                    exit = true;
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }

            Console.WriteLine();
        }

       
        Console.WriteLine("\nThank you for using the Recipe App!");
    }
}
