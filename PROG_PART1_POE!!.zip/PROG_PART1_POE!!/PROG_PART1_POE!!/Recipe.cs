﻿class Recipe
{
    private Ingredient[] ingredients;
    private double[] originalQuantities; // Stores the original quantities for resetting
    private string[] steps;

  
    public Recipe()
    {
        ingredients = new Ingredient[0]; // Initialize with an empty array
        steps = new string[0]; // Initialize with an empty array
    }

    // Method to enter recipe details
    public void EnterDetails()
    {
        int numIngredients;

        // Input validation for the number of ingredients
        while (true)
        {
            Console.Write("\nEnter the number of ingredients: ");
            if (!int.TryParse(Console.ReadLine(), out numIngredients) || numIngredients <= 0)
            {
                Console.WriteLine("Invalid input. Please enter a positive integer.");
            }
            else
            {
                break;
            }
        }

        // Initialize arrays with the number of ingredients
        ingredients = new Ingredient[numIngredients];
        originalQuantities = new double[numIngredients]; // Initialize original quantities array
        for (int i = 0; i < numIngredients; i++)
        {
            Console.Write($"Enter the name of ingredient {i + 1}: ");
            string name = Console.ReadLine();

            double quantity;
            // Input validation for ingredient quantity
            while (true)
            {
                Console.Write($"Enter the quantity of {name}: ");
                if (!double.TryParse(Console.ReadLine(), out quantity) || quantity <= 0)
                {
                    Console.WriteLine("Invalid input. Please enter a positive number.");
                }
                else
                {
                    break;
                }
            }

            Console.Write($"Enter the unit of measurement for {name}: ");
            string unit = Console.ReadLine();

            ingredients[i] = new Ingredient { Name = name, Quantity = quantity, Unit = unit };
            originalQuantities[i] = quantity; // Store original quantity
        }

        int numSteps;
        // Input validation for the number of steps
        while (true)
        {
            Console.Write("\nEnter the number of steps: ");
            if (!int.TryParse(Console.ReadLine(), out numSteps) || numSteps <= 0)
            {
                Console.WriteLine("Invalid input. Please enter a positive integer.");
            }
            else
            {
                break;
            }
        }

        // Initialize steps array
        steps = new string[numSteps];
        for (int i = 0; i < numSteps; i++)
        {
            Console.Write($"Enter step {i + 1}: ");
            steps[i] = Console.ReadLine();
        }

        Console.WriteLine("Recipe details entered successfully!");
    }

    // Method to display recipe
    public void Display()
    {
        Console.WriteLine("\nRecipe:");

        if (ingredients.Length == 0)
        {
            Console.WriteLine("No ingredients entered.");
        }
        else
        {
            Console.WriteLine("\nIngredients:");

            foreach (var ingredient in ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }
        }

        if (steps.Length == 0)
        {
            Console.WriteLine("No steps entered.");
        }
        else
        {
            Console.WriteLine("\nSteps:");

            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i]}");
            }
        }
    }

    // Method to scale recipe
    public void Scale()
    {
        Console.Write("\nEnter scale factor (0.5, 2, or 3): ");
        double scaleFactor;
        // Input validation for scale factor
        if (!double.TryParse(Console.ReadLine(), out scaleFactor) ||
            (scaleFactor != 0.5 && scaleFactor != 2 && scaleFactor != 3))
        {
            Console.WriteLine("Invalid scale factor. Please enter 0.5, 2, or 3.");
            return;
        }

        // Scale each ingredient quantity
        foreach (var ingredient in ingredients)
        {
            ingredient.Quantity *= scaleFactor;
        }

        Console.WriteLine("Recipe scaled successfully!");
    }

    // Method to reset ingredient quantities to original values
    public void ResetQuantities()
    {
        // Restore quantities from original values
        for (int i = 0; i < ingredients.Length; i++)
        {
            ingredients[i].Quantity = originalQuantities[i];
        }

        Console.WriteLine("Quantities reset successfully!");
    }

    // Method to clear all recipe data
    public void ClearData()
    {
        ingredients = new Ingredient[0]; // Reset to an empty array
        steps = new string[0]; // Reset to an empty array

        Console.WriteLine("Recipe data cleared successfully!");
    }
}
