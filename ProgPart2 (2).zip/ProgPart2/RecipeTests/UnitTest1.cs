// UnitTest1.cs

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace RecipeTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestCalculateTotalCalories()
        {
            // Arrange
            var recipe = new Recipe();
            recipe.Name = "Test Recipe";
            recipe.Ingredients = new List<Ingredient>
            {
                new Ingredient { Name = "Ingredient 1", Quantity = 100, Calories = 50 },
                new Ingredient { Name = "Ingredient 2", Quantity = 200, Calories = 30 },
                new Ingredient { Name = "Ingredient 3", Quantity = 150, Calories = 70 }
            };

            // Act
            double totalCalories = recipe.CalculateTotalCalories();

            // Assert
            Assert.AreEqual(21500, totalCalories); // Total calories should be: (100 * 50) + (200 * 30) + (150 * 70) = 5000 + 6000 + 10500 = 21500
        }
    }
}