﻿using System.Collections.Generic;
using System.Linq;

namespace RecipeAppWPF
{
    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<string> Steps { get; set; }

        public double TotalCalories => Ingredients.Sum(i => i.Calories);
    }
}