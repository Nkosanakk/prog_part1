﻿using System.Windows;
using System.Collections.Generic;

namespace RecipeAppWPF
{
    public partial class AddRecipe : Window
    {
        public Recipe NewRecipe { get; private set; }
        private List<Ingredient> ingredients = new List<Ingredient>();
        private List<string> steps = new List<string>();

        public AddRecipe()
        {
            InitializeComponent();
            lvIngredients.ItemsSource = ingredients;
            lvSteps.ItemsSource = steps;
        }

        private void btnAddIngredient_Click(object sender, RoutedEventArgs e)
        {
            AddIngredient addIngredient = new AddIngredient();
            if (addIngredient.ShowDialog() == true)
            {
                if (addIngredient.NewIngredient != null)
                {
                    ingredients.Add(addIngredient.NewIngredient);
                    lvIngredients.Items.Refresh();
                }
            }
        }

        private void btnAddStep_Click(object sender, RoutedEventArgs e)
        {
            string step = Microsoft.VisualBasic.Interaction.InputBox("Enter the step:", "Add Step", "");
            if (!string.IsNullOrEmpty(step))
            {
                steps.Add(step);
                lvSteps.Items.Refresh();
            }
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtRecipeName.Text) && ingredients.Count > 0 && steps.Count > 0)
            {
                NewRecipe = new Recipe
                {
                    Name = txtRecipeName.Text,
                    Ingredients = ingredients,
                    Steps = steps
                };
                DialogResult = true;
            }
            else
            {
                MessageBox.Show("Please fill out all fields before saving.");
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}