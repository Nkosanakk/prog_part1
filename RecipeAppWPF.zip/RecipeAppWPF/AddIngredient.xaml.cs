﻿using System.Windows;
using System.Windows.Controls;

namespace RecipeAppWPF
{
    public partial class AddIngredient : Window
    {
        public Ingredient NewIngredient { get; private set; }

        public AddIngredient()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtName.Text) &&
                double.TryParse(txtQuantity.Text, out double quantity) &&
                !string.IsNullOrEmpty(txtUnit.Text) &&
                double.TryParse(txtCalories.Text, out double calories) &&
                cbFoodGroup.SelectedItem != null)
            {
                NewIngredient = new Ingredient
                {
                    Name = txtName.Text,
                    Quantity = quantity,
                    OriginalQuantity = quantity,
                    Unit = txtUnit.Text,
                    Calories = calories,
                    FoodGroup = (cbFoodGroup.SelectedItem as ComboBoxItem).Content.ToString()
                };
                DialogResult = true;
            }
            else
            {
                MessageBox.Show("Please fill out all fields correctly before saving.");
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}