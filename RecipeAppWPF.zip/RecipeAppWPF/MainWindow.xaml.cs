﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace RecipeAppWPF
{
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();

        public MainWindow()
        {
            InitializeComponent();
            LoadRecipes();
            InitializePlaceholders();
        }

        private void LoadRecipes()
        {
            lvRecipes.ItemsSource = recipes;
        }

        private void InitializePlaceholders()
        {
            SetPlaceholder(txtFilterIngredient, "Ingredient");
            SetPlaceholder(txtFilterMaxCalories, "Max Calories");
        }

        private void SetPlaceholder(TextBox textBox, string placeholder)
        {
            if (string.IsNullOrEmpty(textBox.Text))
            {
                textBox.Text = placeholder;
                textBox.Foreground = new SolidColorBrush(Colors.Gray);
            }
        }

        private void RemovePlaceholder(TextBox textBox)
        {
            if (textBox.Foreground == new SolidColorBrush(Colors.Gray))
            {
                textBox.Text = string.Empty;
                textBox.Foreground = new SolidColorBrush(Colors.Black);
            }
        }

        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            var textBox = sender as TextBox;
            RemovePlaceholder(textBox);
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            var textBox = sender as TextBox;
            if (string.IsNullOrEmpty(textBox.Text))
            {
                SetPlaceholder(textBox, textBox.Tag.ToString());
            }
        }

        private void btnEnterRecipe_Click(object sender, RoutedEventArgs e)
        {
            AddRecipe addRecipe = new AddRecipe();
            if (addRecipe.ShowDialog() == true)
            {
                if (addRecipe.NewRecipe != null && addRecipe.NewRecipe.Ingredients.Count > 0 && addRecipe.NewRecipe.Steps.Count > 0)
                {
                    recipes.Add(addRecipe.NewRecipe);
                    LoadRecipes();
                    MessageBox.Show("Recipe added successfully!");
                }
                else
                {
                    MessageBox.Show("Failed to add recipe. Please ensure all fields are filled, including steps.");
                }
            }
        }

        private void btnDisplayAll_Click(object sender, RoutedEventArgs e)
        {
            DisplayAllRecipeNames();
        }

        private void DisplayAllRecipeNames()
        {
            string allRecipesNames = "All Recipes:\n\n";

            foreach (var recipe in recipes)
            {
                allRecipesNames += $"{recipe.Name}\n";
            }

            MessageBox.Show(allRecipesNames);
        }

        private void btnDisplayByName_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = Microsoft.VisualBasic.Interaction.InputBox("Enter the name of the recipe to display:", "Display Recipe by Name", "");
            Recipe recipe = recipes.FirstOrDefault(r => r.Name == recipeName);
            if (recipe != null)
            {
                DisplayRecipeDetails(recipe);
            }
            else
            {
                MessageBox.Show("Recipe not found.");
            }
        }

        private void DisplayRecipeDetails(Recipe recipe)
        {
            string recipeDetails = $"Recipe Name: {recipe.Name}\n";
            recipeDetails += $"Total Calories: {recipe.TotalCalories}\n";
            recipeDetails += $"Ingredients:\n";
            foreach (var ingredient in recipe.Ingredients)
            {
                recipeDetails += $"- Name: {ingredient.Name}\n";
                recipeDetails += $"  Quantity: {ingredient.Quantity}\n";
                recipeDetails += $"  Calories: {ingredient.Calories}\n";
                recipeDetails += $"  Food Group: {ingredient.FoodGroup}\n";
                recipeDetails += $"  Unit: {ingredient.Unit}\n"; // Explicitly include Unit here
            }
            recipeDetails += $"Steps:\n";
            for (int i = 0; i < recipe.Steps.Count; i++)
            {
                recipeDetails += $"Step {i + 1}: {recipe.Steps[i]}\n";
            }
            MessageBox.Show(recipeDetails);
        }

        private void btnScale_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = Microsoft.VisualBasic.Interaction.InputBox("Enter the name of the recipe to scale:", "Scale Recipe", "");
            Recipe recipeToScale = recipes.FirstOrDefault(r => r.Name == recipeName);
            if (recipeToScale != null)
            {
                string scaleInput = Microsoft.VisualBasic.Interaction.InputBox("Enter scale factor (0.5, 2, or 3):", "Scale Factor", "");
                double scale;
                if (double.TryParse(scaleInput, out scale))
                {
                    if (scale == 0.5 || scale == 2 || scale == 3)
                    {
                        // Scale the quantities of ingredients
                        foreach (var ingredient in recipeToScale.Ingredients)
                        {
                            ingredient.Quantity *= scale;
                        }
                        MessageBox.Show($"Recipe '{recipeName}' scaled by {scale}.");
                    }
                    else
                    {
                        MessageBox.Show("Invalid scale factor. Please enter 0.5, 2, or 3.");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid input. Please enter a number.");
                }
            }
            else
            {
                MessageBox.Show("Recipe not found.");
            }
        }

        private void btnResetQuantities_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = Microsoft.VisualBasic.Interaction.InputBox("Enter the name of the recipe to reset quantities:", "Reset Quantities", "");
            Recipe recipe = recipes.FirstOrDefault(r => r.Name == recipeName);
            if (recipe != null)
            {
                // Reset quantities for the recipe
                foreach (var ingredient in recipe.Ingredients)
                {
                    ingredient.Quantity = 0; // You can set the quantity to whatever default value you prefer
                }
                MessageBox.Show($"Quantities reset for recipe '{recipeName}'.");
            }
            else
            {
                MessageBox.Show("Recipe not found.");
            }
        }

        private void btnClearData_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = Microsoft.VisualBasic.Interaction.InputBox("Enter the name of the recipe to clear data:", "Clear Data by Name", "");
            Recipe recipeToRemove = recipes.FirstOrDefault(r => r.Name == recipeName);
            if (recipeToRemove != null)
            {
                recipes.Remove(recipeToRemove);
                LoadRecipes();
                MessageBox.Show($"Data cleared for recipe '{recipeName}'.");
            }
            else
            {
                MessageBox.Show("Recipe not found.");
            }
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnFilter_Click(object sender, RoutedEventArgs e)
        {
            string ingredient = txtFilterIngredient.Text.ToLower();
            string foodGroup = ((ComboBoxItem)cbFilterFoodGroup.SelectedItem).Content.ToString();
            string maxCaloriesText = txtFilterMaxCalories.Text;

            int maxCalories = 0;
            if (!string.IsNullOrWhiteSpace(maxCaloriesText) && !int.TryParse(maxCaloriesText, out maxCalories))
            {
                MessageBox.Show("Please enter a valid number for max calories.");
                return;
            }

            var filteredRecipes = recipes.Where(r =>
                (string.IsNullOrWhiteSpace(ingredient) || r.Ingredients.Any(i => i.Name.ToLower().Contains(ingredient))) &&
                (foodGroup == "All" || r.Ingredients.Any(i => i.FoodGroup == foodGroup)) &&
                (maxCalories == 0 || r.TotalCalories <= maxCalories)).ToList();

            lvRecipes.ItemsSource = filteredRecipes;

            if (filteredRecipes.Count == 0)
            {
                MessageBox.Show("No recipes match the filter criteria.");
            }
        }
    }
}